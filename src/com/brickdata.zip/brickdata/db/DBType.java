package com.brickdata.db;

public enum DBType {
	HSQLDB, MYSQL
}
