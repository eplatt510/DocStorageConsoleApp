package com.brickdata.db.beans;

public class Location {
	
	private String locationNumber;
	private int quantity;
	
	public String getLocationNumber() {
		return locationNumber;
	}
	
	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
		
	
	}
	
	

}
